#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"    // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "myCamera.h" // Camera class

using namespace std; // Standard namespace

int global_num_light_comp = 0;
/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif
float isModule = 0.0;
// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Project 2"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbo;         // Handle for the vertex buffer object
        GLuint nVertices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    GLMesh gMeshCylTop;
    GLMesh gMeshBlueRect;
    GLMesh gMeshMedBottle;
    GLMesh gMeshMedBottleTop;
    GLMesh gMeshPlane;
    // Texture
    GLuint gTextureId;
    GLuint gTextureIdCylTop;
    GLuint gTextureIdBlueRect;
    GLuint gTextureIdMedBody;
    GLuint gTextureIdMedTop;
    GLuint gTexturePlane;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader programs
    GLuint gCubeProgramId;
    GLuint cylTopObject;
    GLuint blueRectPrism;
    GLuint medicineBottleBody;
    GLuint medicineBottleTop;
    GLuint gLampProgramId;
    GLuint gLamp2ProgramId;
    GLuint planeID;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 7.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // Subject position and scale
    glm::vec3 gCubePosition(0.0f, 0.0f, 0.0f);
    glm::vec3 gCubeScale(2.0f);

    // Cube and light color
    //m::vec3 gObjectColor(0.6f, 0.5f, 0.75f);
    glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
    glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);   // THIS is where to change the color at 
    glm::vec3 gLight2Color(1.0f, 1.0f, 1.0f);   // THIS is where to change the color at 

    // Light position and scale
    glm::vec3 gLightPosition(1.5f, 0.5f, 3.0f);
    glm::vec3 gLight2Position(0.0f, 0.0f, -3.0f);
    glm::vec3 gLightScale(0.3f);

    // Lamp animation
    bool gIsLampOrbiting = true;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UCreateMesh2(GLMesh& mesh);
void UCreateMeshBlueRect(GLMesh& mesh);
void UCreateMeshMedBottle(GLMesh& mesh);
void UCreateMeshMedTop(GLMesh& mesh);
void UCreateMeshPlane(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Cube Vertex Shader Source Code*/
const GLchar* cubeVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Cube Fragment Shader Source Code*/
const GLchar* cubeFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 light2Color;
uniform vec3 lightPos;
uniform vec3 light2Pos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;
float isModule;



void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/
    float light2intensity = 2;//  (isModule == 1.0 ? .1 : 2);
    float lightintensity = 2;// (isModule == 1.0 ? 1 : 2);

    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    vec3 light2Direction = normalize(light2Pos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    float impact2 = max(dot(norm, light2Direction), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = (lightintensity * impact * lightColor + light2intensity * impact2 * light2Color); // Generate diffuse light color
    //vec3 diffuse = (impact + .1 * impact2) * (lightColor + light2Color); // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.8f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    vec3 reflectDir2 = reflect(-light2Direction, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize);
    //vec3 specular = specularIntensity * (specularComponent + .1 * specularComponent2) * lightColor;
    vec3 specular = lightintensity * specularIntensity * specularComponent * lightColor + light2intensity * specularComponent2 * light2Color;
    //vec3 specular = specularIntensity * (specularComponent + .1*specularComponent2) * (lightColor + light2Color);

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);


/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0   Here's what to change to make light green (i think) 
}
);


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object
    UCreateMesh2(gMeshCylTop); // Calls the function to create the Vertex Buffer Object
    UCreateMeshBlueRect(gMeshBlueRect); // Calls the function to create the Vertex Buffer Object
    UCreateMeshMedBottle(gMeshMedBottle); // Calls the function to create the Vertex Buffer Object
    UCreateMeshMedTop(gMeshMedBottleTop); // Calls the function to create the Vertex Buffer Object   START HERE!!!!!!
    UCreateMeshPlane(gMeshPlane); // Calls the function to create the Vertex Buffer Object   START HERE!!!!!!

    // Create the shader programs
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCubeProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, cylTopObject))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, planeID))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLamp2ProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, blueRectPrism))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, medicineBottleBody))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, medicineBottleTop))
        return EXIT_FAILURE;



    // Load texture for main cylinder 
    const char* texFilename = "";
    if (isModule == 1)
        texFilename = "resources/textures/brick texture.jpg";
    else
        texFilename = "resources/textures/RandomHearts.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    //load texture for main cylinder top 
    texFilename = "resources/textures/gold3.jpg";
    if (!UCreateTexture(texFilename, gTextureIdCylTop))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // load texture for  Blue rect prism
    texFilename = "resources/textures/blue background.jpg";
    if (!UCreateTexture(texFilename, gTextureIdBlueRect))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // texture for medicine bottle body
    texFilename = "resources/textures/MedBody.jpg";
    if (!UCreateTexture(texFilename, gTextureIdMedBody))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // texture for medicine bottle top 
    texFilename = "resources/textures/blue background.jpg";
    if (!UCreateTexture(texFilename, gTextureIdMedTop))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // texture for plane 
    texFilename = "resources/textures/MedBody.jpg";
    if (!UCreateTexture(texFilename, gTexturePlane))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    glUseProgram(planeID);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(planeID, "uTexture"), 0);

    glUseProgram(cylTopObject);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(cylTopObject, "uTexture"), 0);

    glUseProgram(blueRectPrism);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(blueRectPrism, "uTexture"), 0);

    glUseProgram(medicineBottleBody);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(medicineBottleBody, "uTexture"), 0);

    glUseProgram(medicineBottleTop);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(medicineBottleTop, "uTexture"), 0);


    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCubeProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCubeProgramId, "uTexture"), 0);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureId);

    // Release shader programs
    UDestroyShaderProgram(gCubeProgramId);
    UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    //gCameraPos -= glm::normalize(glm::cross(gCameraFront, gCameraUp)) * cameraOffset;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS && gTexWrapMode != GL_REPEAT)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_REPEAT;

        cout << "Current Texture Wrapping Mode: REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS && gTexWrapMode != GL_MIRRORED_REPEAT)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_MIRRORED_REPEAT;

        cout << "Current Texture Wrapping Mode: MIRRORED REPEAT" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_EDGE)
    {
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_EDGE;

        cout << "Current Texture Wrapping Mode: CLAMP TO EDGE" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_BORDER)
    {
        float color[] = { 1.0f, 0.0f, 1.0f, 1.0f };
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);

        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        glBindTexture(GL_TEXTURE_2D, 0);

        gTexWrapMode = GL_CLAMP_TO_BORDER;

        cout << "Current Texture Wrapping Mode: CLAMP TO BORDER" << endl;
    }

    if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
    {
        gUVScale += 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }
    else if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
    {
        gUVScale -= 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }

    // Pause and resume lamp orbiting
    static bool isLKeyDown = false;
    if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS && !gIsLampOrbiting)
        gIsLampOrbiting = true;
    else if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS && gIsLampOrbiting)
        gIsLampOrbiting = false;

}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset * .03, yoffset * .03);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Functioned called to render a frame
void URender()
{
    // Lamp orbits around the origin
    const float angularVelocity = glm::radians(45.0f);
    if (/*gIsLampOrbiting*/ false)
    {
        glm::vec4 newPosition = glm::rotate(angularVelocity * gDeltaTime, glm::vec3(0.0f, 1.0f, 0.0f)) * glm::vec4(gLightPosition, 1.0f);
        gLightPosition.x = newPosition.x;
        gLightPosition.y = newPosition.y;
        gLightPosition.z = newPosition.z;
    }

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    {  // for original Cylinder top 

        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMeshCylTop.vao);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(cylTopObject);

        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::translate(gCubePosition) * glm::scale(gCubeScale);

        // camera/view transformation
        glm::mat4 view = gCamera.GetViewMatrix();

        // Creates a perspective projection
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(cylTopObject, "model");
        GLint viewLoc = glGetUniformLocation(cylTopObject, "view");
        GLint projLoc = glGetUniformLocation(cylTopObject, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(cylTopObject, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(cylTopObject, "lightColor");
        GLint light2ColorLoc = glGetUniformLocation(cylTopObject, "light2Color");
        GLint lightPositionLoc = glGetUniformLocation(cylTopObject, "lightPos");
        GLint light2PositionLoc = glGetUniformLocation(cylTopObject, "light2Pos");
        GLint viewPositionLoc = glGetUniformLocation(cylTopObject, "viewPosition");
        GLint isModLoc = glGetUniformLocation(cylTopObject, "isModule");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform1f(isModLoc, isModule);
        glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(light2ColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
        glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        glUniform3f(light2PositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(cylTopObject, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdCylTop);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMeshCylTop.nVertices);
    }

    {  // for Blue rect prisim  

        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMeshBlueRect.vao);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(blueRectPrism);

        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::translate(gCubePosition) * glm::scale(gCubeScale);

        // camera/view transformation
        glm::mat4 view = gCamera.GetViewMatrix();

        // Creates a perspective projection
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(blueRectPrism, "model");
        GLint viewLoc = glGetUniformLocation(blueRectPrism, "view");
        GLint projLoc = glGetUniformLocation(blueRectPrism, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(blueRectPrism, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(blueRectPrism, "lightColor");
        GLint light2ColorLoc = glGetUniformLocation(blueRectPrism, "light2Color");
        GLint lightPositionLoc = glGetUniformLocation(blueRectPrism, "lightPos");
        GLint light2PositionLoc = glGetUniformLocation(blueRectPrism, "light2Pos");
        GLint viewPositionLoc = glGetUniformLocation(blueRectPrism, "viewPosition");
        GLint isModLoc = glGetUniformLocation(blueRectPrism, "isModule");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform1f(isModLoc, isModule);
        glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(light2ColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
        glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        glUniform3f(light2PositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(blueRectPrism, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdBlueRect);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMeshBlueRect.nVertices);
    }

    {  // for MEd Bottle Body   

        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMeshMedBottle.vao);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(medicineBottleBody);

        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::translate(gCubePosition) * glm::scale(gCubeScale);

        // camera/view transformation
        glm::mat4 view = gCamera.GetViewMatrix();

        // Creates a perspective projection
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(medicineBottleBody, "model");
        GLint viewLoc = glGetUniformLocation(medicineBottleBody, "view");
        GLint projLoc = glGetUniformLocation(medicineBottleBody, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(medicineBottleBody, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(medicineBottleBody, "lightColor");
        GLint light2ColorLoc = glGetUniformLocation(medicineBottleBody, "light2Color");
        GLint lightPositionLoc = glGetUniformLocation(medicineBottleBody, "lightPos");
        GLint light2PositionLoc = glGetUniformLocation(medicineBottleBody, "light2Pos");
        GLint viewPositionLoc = glGetUniformLocation(medicineBottleBody, "viewPosition");
        GLint isModLoc = glGetUniformLocation(medicineBottleBody, "isModule");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform1f(isModLoc, isModule);
        glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(light2ColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
        glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        glUniform3f(light2PositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(medicineBottleBody, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdMedBody);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMeshMedBottle.nVertices);
    }


    {  // for Med Bottle Top   

        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMeshMedBottleTop.vao);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(medicineBottleTop);

        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::translate(gCubePosition) * glm::scale(gCubeScale);

        // camera/view transformation
        glm::mat4 view = gCamera.GetViewMatrix();

        // Creates a perspective projection
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(medicineBottleTop, "model");
        GLint viewLoc = glGetUniformLocation(medicineBottleTop, "view");
        GLint projLoc = glGetUniformLocation(medicineBottleTop, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(medicineBottleTop, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(medicineBottleTop, "lightColor");
        GLint light2ColorLoc = glGetUniformLocation(medicineBottleTop, "light2Color");
        GLint lightPositionLoc = glGetUniformLocation(medicineBottleTop, "lightPos");
        GLint light2PositionLoc = glGetUniformLocation(medicineBottleTop, "light2Pos");
        GLint viewPositionLoc = glGetUniformLocation(medicineBottleTop, "viewPosition");
        GLint isModLoc = glGetUniformLocation(medicineBottleTop, "isModule");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform1f(isModLoc, isModule);
        glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(light2ColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
        glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        glUniform3f(light2PositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(medicineBottleTop, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdMedTop);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMeshMedBottleTop.nVertices);
    }

    {  // for Plane 

        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMeshPlane.vao);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(planeID);

        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::translate(gCubePosition) * glm::scale(gCubeScale);

        // camera/view transformation
        glm::mat4 view = gCamera.GetViewMatrix();

        // Creates a perspective projection
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(planeID, "model");
        GLint viewLoc = glGetUniformLocation(planeID, "view");
        GLint projLoc = glGetUniformLocation(planeID, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(planeID, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(planeID, "lightColor");
        GLint light2ColorLoc = glGetUniformLocation(planeID, "light2Color");
        GLint lightPositionLoc = glGetUniformLocation(planeID, "lightPos");
        GLint light2PositionLoc = glGetUniformLocation(planeID, "light2Pos");
        GLint viewPositionLoc = glGetUniformLocation(planeID, "viewPosition");
        GLint isModLoc = glGetUniformLocation(planeID, "isModule");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform1f(isModLoc, isModule);
        glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(light2ColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
        glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        glUniform3f(light2PositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(planeID, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTexturePlane);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMeshPlane.nVertices);
    }
    /////////////////////////////   ******************************************************   //////////////////////////////////////////////////////////

    // Activate the cube VAO (used by cube and lamp)
    glBindVertexArray(gMesh.vao);

    // CUBE: draw cube
    //----------------
    // Set the shader to be used
    glUseProgram(gCubeProgramId);

    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = glm::translate(gCubePosition) * glm::scale(gCubeScale);

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gCubeProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gCubeProgramId, "view");
    GLint projLoc = glGetUniformLocation(gCubeProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(gCubeProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gCubeProgramId, "lightColor");
    GLint light2ColorLoc = glGetUniformLocation(gCubeProgramId, "light2Color");
    GLint lightPositionLoc = glGetUniformLocation(gCubeProgramId, "lightPos");
    GLint light2PositionLoc = glGetUniformLocation(gCubeProgramId, "light2Pos");
    GLint viewPositionLoc = glGetUniformLocation(gCubeProgramId, "viewPosition");
    GLint isModLoc = glGetUniformLocation(gCubeProgramId, "isModule");

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform1f(isModLoc, isModule);
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(light2ColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    glUniform3f(light2PositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gCubeProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);

    // LAMP: draw lamp
    //----------------
    glUseProgram(gLampProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    if (isModule == 1.0)
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);
    else
        glDrawArrays(GL_TRIANGLES, 0, 300);

    // LAMP: draw 2nd lamp
    //----------------
    glUseProgram(gLamp2ProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLight2Position) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLamp2ProgramId, "model");
    viewLoc = glGetUniformLocation(gLamp2ProgramId, "view");
    projLoc = glGetUniformLocation(gLamp2ProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    if (isModule == 1.0)
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);
    else
        glDrawArrays(GL_TRIANGLES, 0, 300);


    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


struct pt_3d {
    GLfloat x;
    GLfloat y;
    GLfloat z;
};


pt_3d rotXZ(pt_3d pt, double angleDegrees) {
    double angleRad = angleDegrees * 3.14159265358979323846 / 180;
    return pt_3d{ static_cast<float>(pt.x * cos(angleRad) - pt.z * sin(angleRad)),
                pt.y,
                static_cast<float>(pt.z * cos(angleRad) + pt.x * sin(angleRad)) };
}

void updateRGb(GLfloat& r, GLfloat& b, GLfloat& g, int div) {
    r = std::fmod(r + .01, 1);  b = std::fmod(b + .05, 1);   g = std::fmod(g + .1, 1);
}

void translateToOrigin(pt_3d dispCenter, pt_3d *satellite) {
    satellite->x = satellite->x - dispCenter.x;
    satellite->z = satellite->z - dispCenter.z;
}

void translateFromOrigin(pt_3d dispCenter, pt_3d* satellite) {
    satellite->x = satellite->x + dispCenter.x;
    satellite->z = satellite->z + dispCenter.z;
}



int generateRectangularPrism(GLfloat* vertices, GLfloat xLen, GLfloat yHeight, GLfloat zWidth, GLfloat centerX, GLfloat centerZ, GLfloat bottomY)
{
    int indAnchor = 0;
    int numVerticies = 0;
    for (GLfloat offset = 0.0f; offset <= yHeight; offset += yHeight) {
        //vertex 1 (X Z plane) bottom & top
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX;   vertices[indAnchor++] = bottomY + offset;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 2
        vertices[indAnchor++] = centerX + xLen / 2;   vertices[indAnchor++] = bottomY + offset;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ;
        //vertex 2 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 3 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX;   vertices[indAnchor++] = bottomY + offset;    vertices[indAnchor++] = zWidth / 2 + centerZ;
        //vertex 3 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 1.0f;  numVerticies++;

        //vertex 4     (X Z plane) bottom & top 
        int inc = 18;
        vertices[indAnchor++] = xLen / 2 + centerX;   vertices[indAnchor++] = bottomY + offset;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ;
        //vertex 4 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 5 
        vertices[indAnchor++] = xLen / 2 + centerX;   vertices[indAnchor++] = bottomY + offset;    vertices[indAnchor++] = zWidth / 2 + centerZ;
        //vertex 5 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 6 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX;   vertices[indAnchor++] = bottomY + offset;    vertices[indAnchor++] = zWidth / 2 + centerZ;
        //vertex 6 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 1.0f;  numVerticies++;
    }

    for (GLfloat offset = 0.0f; offset <= xLen; offset += xLen) {
        //vertex 1 (Z Y plane) left & right
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX + offset;   vertices[indAnchor++] = bottomY ;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 2
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX + offset;   vertices[indAnchor++] = bottomY + yHeight;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ;
        //vertex 2 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 3 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX + offset;   vertices[indAnchor++] = bottomY ;    vertices[indAnchor++] = zWidth / 2 + centerZ;
        //vertex 3 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 1.0f;  numVerticies++;

        //vertex 4     (Z Y plane) left & right 
        int inc = 18;
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX + offset;   vertices[indAnchor++] = bottomY + yHeight;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ;
        //vertex 4 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 5 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX + offset;   vertices[indAnchor++] = bottomY + yHeight;    vertices[indAnchor++] = zWidth / 2 + centerZ;
        //vertex 5 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 6 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX + offset;   vertices[indAnchor++] = bottomY;    vertices[indAnchor++] = zWidth / 2 + centerZ;
        //vertex 6 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 1.0f;  numVerticies++;
    }

    for (GLfloat offset = 0.0f; offset <= zWidth; offset += zWidth) {
        //vertex 1 (X Y plane) back & front
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX ;   vertices[indAnchor++] = bottomY;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ + offset;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 2
        vertices[indAnchor++] = xLen / 2 + centerX ;   vertices[indAnchor++] = bottomY;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ + offset;
        //vertex 2 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 3 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX ;   vertices[indAnchor++] = bottomY + yHeight;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ + offset;
        //vertex 3 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 1.0f;  numVerticies++;

        //vertex 4     (X Y plane) back & front 
        int inc = 18;
        vertices[indAnchor++] =  xLen / 2 + centerX ;   vertices[indAnchor++] = bottomY ;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ + offset;
        //vertex 4 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 5 
        vertices[indAnchor++] =  xLen / 2 + centerX ;   vertices[indAnchor++] = bottomY + yHeight;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ + offset;
        //vertex 5 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 0.0f;  numVerticies++;
        //vertex 6 
        vertices[indAnchor++] = (-1) * xLen / 2 + centerX ;   vertices[indAnchor++] = bottomY + yHeight;    vertices[indAnchor++] = (-1) * zWidth / 2 + centerZ + offset;
        //vertex 6 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 0.0f;   vertices[indAnchor++] = 1.0f;  numVerticies++;
    }


    return numVerticies;
}

int generatePlane(GLfloat* vertices,GLfloat radius) {
    
    int indAnchor = 0;

    if (true) {
        // now a big ole plane at the bottom 
        double size = 4 * radius;
        //vertex 1 
        //vertices[start] = (-1) * size;   vertices[start + 1] = 0;    vertices[start + 2] = (-1) * size;
        vertices[indAnchor++] = (-1) * size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = (-1) * size;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 2
        vertices[indAnchor++] = size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = (-1) * size;
        //vertex 2 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 3 
        vertices[indAnchor++] = (-1) * size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = size;
        //vertex 3 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;

        //vertex 4
        int inc = 18;
        vertices[indAnchor++] = size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = (-1) * size;
        //vertex 4 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 5 
        vertices[indAnchor++] = size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = size;
        //vertex 5 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 6 
        vertices[indAnchor++] = (-1) * size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = size;
        //vertex 6 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
    }
    return 2;
}



int generateCylinderPoints(GLfloat* vertices, double numTriPerCircle, GLfloat radius, GLfloat cylHeight, GLfloat cylBottom, bool doPlane, GLfloat centerX, GLfloat centerZ) {
    double numSegments = numTriPerCircle;
    double segmentsDone = 0;
    double angle = 360 / numSegments;

    int numTriangles = 0;

    //GLfloat* vertices = new GLfloat[3  *  6 * numSegments];

    //bottom circle 
    GLfloat universalY = cylBottom;
    pt_3d p1 = pt_3d{ centerX, universalY, centerZ + radius };
    pt_3d p3 = pt_3d{ centerX, universalY, centerZ };

    GLfloat r = 1.0f, g = 0.0f, b = 0.0f;

    int indAnchor = 0;

    translateToOrigin(p3, &p1);
    for (pt_3d p2 = rotXZ(p1, angle); segmentsDone < numSegments; segmentsDone++, p1 = p2, p2 = rotXZ(p1, angle)) {
        translateFromOrigin(p3, &p1);
        translateFromOrigin(p3, &p2);
        //int indAnchor = segmentsDone * 6 * 3 * 2;   //  2 triangles, 3 pts (x, y, z) and 

        // Flat triangle 
        //vertex 1 position 
        vertices[indAnchor++] = p1.x; vertices[indAnchor++] = p1.y;  vertices[indAnchor++] = p1.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 1 texture 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 0.0f; numTriangles++;


        //vertex 2 position 
        vertices[indAnchor++] = p2.x; vertices[indAnchor++] = p2.y;  vertices[indAnchor++] = p2.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 2 texture 
        vertices[indAnchor++] = 1.0f; vertices[indAnchor++] = 0.0f;  numTriangles++;

        //vertex 3 position 
        vertices[indAnchor++] = p3.x; vertices[indAnchor++] = p3.y;  vertices[indAnchor++] = p3.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 3 texture 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;   numTriangles++;

        //indAnchor = indAnchor + 18;

        // upright triangle 
        //vertex 1 position 
        vertices[indAnchor++] = p1.x; vertices[indAnchor++] = p1.y;  vertices[indAnchor++] = p1.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 1 texture 
        vertices[indAnchor++] = 0.0; vertices[indAnchor++] = 0.0;   numTriangles++;

        //vertex 2 position 
        vertices[indAnchor++] = p2.x; vertices[indAnchor++] = p2.y;  vertices[indAnchor++] = p2.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 2 texture 
        vertices[indAnchor++] = 1.0; vertices[indAnchor++] = 0.0;    numTriangles++;

        //vertex 3 position 
        vertices[indAnchor++] = p1.x; vertices[indAnchor++] = cylHeight + universalY;  vertices[indAnchor++] = p1.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 3 texture 
        vertices[indAnchor++] = 0.0; vertices[indAnchor++] = 1.0;   numTriangles++;

        translateToOrigin(p3, &p1);
        translateToOrigin(p3, &p2);
    }

    //top circle 
    //universalY = 0.3f;
    p1 = pt_3d{ centerX, cylHeight + universalY, centerZ + radius };
    p3 = pt_3d{ centerX, cylHeight + universalY, centerZ };

    segmentsDone = 0;
    translateToOrigin(p3, &p1);
    for (pt_3d p2 = rotXZ(p1, angle); segmentsDone < numSegments; segmentsDone++, p1 = p2, p2 = rotXZ(p1, angle)) {
        translateFromOrigin(p3, &p1);
        translateFromOrigin(p3, &p2);
        // int indAnchor = segmentsDone * 6 * 3 * 2 + numSegments * 6 * 3 * 2;

         //vertex 1 position 
        vertices[indAnchor++] = p1.x; vertices[indAnchor++] = p1.y;  vertices[indAnchor++] = p1.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 1 texture 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 0.0f;   numTriangles++;

        //vertex 2 position 
        vertices[indAnchor++] = p2.x; vertices[indAnchor++] = p2.y;  vertices[indAnchor++] = p2.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 2 texture 
        vertices[indAnchor++] = 1.0f; vertices[indAnchor++] = 0.0f;  numTriangles++;

        //vertex 3 position 
        vertices[indAnchor++] = p3.x; vertices[indAnchor++] = p3.y;  vertices[indAnchor++] = p3.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 3 texture 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;   numTriangles++;


        // downward pointing triangle 
        //vertex 1 position 
        vertices[indAnchor++] = p1.x; vertices[indAnchor++] = p1.y;  vertices[indAnchor++] = p1.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 1 texture 
        vertices[indAnchor++] = 0.0; vertices[indAnchor++] = 0.0;   numTriangles++;

        //vertex 2 position 
        vertices[indAnchor++] = p2.x; vertices[indAnchor++] = p2.y;  vertices[indAnchor++] = p2.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 2 texture 
        vertices[indAnchor++] = 1.0; vertices[indAnchor++] = 0.0;    numTriangles++;

        //vertex 3 position 
        vertices[indAnchor++] = p2.x; vertices[indAnchor++] = universalY;  vertices[indAnchor++] = p2.z;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        //vertex 3 texture 
        vertices[indAnchor++] = 0.0; vertices[indAnchor++] = 1.0;    numTriangles++;

        translateToOrigin(p3, &p1);
        translateToOrigin(p3, &p2);
    }


    if (doPlane) {
        // now a big ole plane at the bottom 
        int start = numSegments * 6 * 3 * 2 * 2;   // originally, start wsas used place of indAnchor 
        double size = 4 * radius;
        //vertex 1 
        //vertices[start] = (-1) * size;   vertices[start + 1] = 0;    vertices[start + 2] = (-1) * size;
        vertices[indAnchor++] = (-1) * size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = (-1) * size;
        //vertex 1 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 2
        vertices[indAnchor++] = size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = (-1) * size;
        //vertex 2 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 3 
        vertices[indAnchor++] = (-1) * size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = size;
        //vertex 3 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;

        //vertex 4
        int inc = 18;
        vertices[indAnchor++] = size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = (-1) * size;
        //vertex 4 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 5 
        vertices[indAnchor++] = size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = size;
        //vertex 5 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
        //vertex 6 
        vertices[indAnchor++] = (-1) * size;   vertices[indAnchor++] = 0;    vertices[indAnchor++] = size;
        //vertex 6 lighting 
        vertices[indAnchor++] = 0.0f; vertices[indAnchor++] = 1.0f;  vertices[indAnchor++] = 0.0f;
        vertices[indAnchor++] = 1.0f;   vertices[indAnchor++] = 1.0f;
    }
    return numTriangles;
}



// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts2[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       /*-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

        //Front Face         //Positive Z Normal
       -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

        //Left Face          //Negative X Normal
       -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
       -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        //Right Face         //Positive X Normal
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        //Bottom Face        //Negative Y Normal
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

        //Top Face           //Positive Y Normal
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,*/


       //T1
      -0.25f, 0.0f, -0.25f,         0.0f,  1.0f,  0.0f,     0.0f, 1.0f,

      -0.25f, 0.0f, 0.25f,          0.0f,  1.0f,  0.0f,     0.0f, 0.0f,

      0.25f, 0.0f, -0.25f,          0.0f,  1.0f,  0.0f,     1.0f, 1.0f,



      //T2
      0.25f,  0.0f, 0.25f,          0.0f,  1.0f,  0.0f,     1.0f, 0.0f,

      -0.25f,  0.0f, 0.25f,         0.0f,  1.0f,  0.0f,     0.0f, 0.0f,

      0.25f,  0.0f, -0.25f,         0.0f,  1.0f,  0.0f,     1.0f, 1.0f,


      //T3
      0.25f,  0.0f, 0.25f,          1.0f,  0.0f,  0.0f,      0.0f, 1.0f,

      0.0f, 0.5f,  0.0f,            1.0f,  0.0f,  0.0f,     1.0f, 0.0f,

      0.25f,  0.0f, -0.25f,         1.0f,  0.0f,  0.0f,     1.0f, 1.0f,



      //T4
       0.25f,  0.0f, -0.25f,        0.0f,  0.0f,  -1.0f,    1.0f, 1.0f,

       0.0f, 0.5f,  0.0f,           0.0f,  0.0f,  -1.0f,    1.0f, 0.0f,

      -0.25f,  0.0f, -0.25f,        0.0f,  0.0f,  -1.0f,    0.0f, 1.0f,


      //T5
      -0.25f,  0.0f, 0.25f,         0.0f,  0.0f,  1.0f,     0.0f, 0.0f,

       0.0f, 0.5f,  0.0f,           0.0f,  0.0f,  1.0f,     1.0f, 0.0f,

      0.25f,  0.0f, 0.25f,          0.0f,  0.0f,  1.0f,     0.0f, 1.0f,


      //T6
      -0.25f,  0.0f, -0.25f,        -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,

       0.0f, 0.5f,  0.0f,           -1.0f,  0.0f,  0.0f,    1.0f, 0.0f,

      -0.25f,  0.0f, 0.25f,         -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    };

    GLfloat verts[100000];
    if (isModule == 1.0) {
        for (int i = 0; i < sizeof(verts2) / sizeof(verts2[0]); i++) {
            verts[i] = verts2[i];
        }
    }
    else {
        //generateCylinderPoints(verts, 50, .15, 0.3f);
        global_num_light_comp = generateCylinderPoints(verts, 25, .8, 0.3f, .1f, false, 0.0f, 0.0f);
        //global_num_light_comp = generateRectangularPrism(verts, 0.9f, 0.3f, 0.4f, 0.3f, 0.3f, 0.0f);
        //global_num_light_comp = 2;
    }


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

GLfloat medBottleHeight = 0.23f;
GLfloat medBottleBottom = 0.1f;
GLfloat medBottleTopHeight = 0.06f;
GLfloat medBottleCenterX = 0.5f, medBottleCenterZ = 1.0f;
GLfloat medBottleLenWid = 0.2f;

GLfloat blueRectWid = 0.5f;

void UCreateMeshBlueRect(GLMesh& mesh)  // rectangle 
{
    GLfloat verts[100000];
    global_num_light_comp = generateRectangularPrism(verts, 1.0f, .85*medBottleHeight, blueRectWid, -1.0f, medBottleCenterZ, medBottleBottom);


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UCreateMeshMedBottle(GLMesh& mesh)  // rectangle 
{
    GLfloat verts[100000];
    global_num_light_comp = generateRectangularPrism(verts, medBottleLenWid, medBottleHeight, medBottleLenWid, medBottleCenterX, medBottleCenterZ, medBottleBottom);
        //generateCylinderPoints(verts, 25, .8, 0.1f, 0.4f, false, 1.0f, -1.0f);


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UCreateMeshPlane(GLMesh& mesh)  // rectangle 
{
    GLfloat verts[100000];
    global_num_light_comp = generatePlane(verts, .8);
    //generateCylinderPoints(verts, 25, .8, 0.1f, 0.4f, false, 1.0f, -1.0f);


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}
void UCreateMeshMedTop(GLMesh& mesh)  // cylinder 
{
    GLfloat verts[100000];
    global_num_light_comp = generateCylinderPoints(verts, 25, .8*(medBottleLenWid/2), medBottleTopHeight, medBottleHeight + medBottleBottom, false, medBottleCenterX, medBottleCenterZ);


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UCreateMesh2(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts2[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
       /*-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

        //Front Face         //Positive Z Normal
       -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,

        //Left Face          //Negative X Normal
       -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
       -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        //Right Face         //Positive X Normal
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        //Bottom Face        //Negative Y Normal
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

        //Top Face           //Positive Y Normal
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,*/


       //T1
      -0.25f, 0.0f, -0.25f,         0.0f,  1.0f,  0.0f,     0.0f, 1.0f,

      -0.25f, 0.0f, 0.25f,          0.0f,  1.0f,  0.0f,     0.0f, 0.0f,

      0.25f, 0.0f, -0.25f,          0.0f,  1.0f,  0.0f,     1.0f, 1.0f,



      //T2
      0.25f,  0.0f, 0.25f,          0.0f,  1.0f,  0.0f,     1.0f, 0.0f,

      -0.25f,  0.0f, 0.25f,         0.0f,  1.0f,  0.0f,     0.0f, 0.0f,

      0.25f,  0.0f, -0.25f,         0.0f,  1.0f,  0.0f,     1.0f, 1.0f,


      //T3
      0.25f,  0.0f, 0.25f,          1.0f,  0.0f,  0.0f,      0.0f, 1.0f,

      0.0f, 0.5f,  0.0f,            1.0f,  0.0f,  0.0f,     1.0f, 0.0f,

      0.25f,  0.0f, -0.25f,         1.0f,  0.0f,  0.0f,     1.0f, 1.0f,



      //T4
       0.25f,  0.0f, -0.25f,        0.0f,  0.0f,  -1.0f,    1.0f, 1.0f,

       0.0f, 0.5f,  0.0f,           0.0f,  0.0f,  -1.0f,    1.0f, 0.0f,

      -0.25f,  0.0f, -0.25f,        0.0f,  0.0f,  -1.0f,    0.0f, 1.0f,


      //T5
      -0.25f,  0.0f, 0.25f,         0.0f,  0.0f,  1.0f,     0.0f, 0.0f,

       0.0f, 0.5f,  0.0f,           0.0f,  0.0f,  1.0f,     1.0f, 0.0f,

      0.25f,  0.0f, 0.25f,          0.0f,  0.0f,  1.0f,     0.0f, 1.0f,


      //T6
      -0.25f,  0.0f, -0.25f,        -1.0f,  0.0f,  0.0f,    0.0f, 1.0f,

       0.0f, 0.5f,  0.0f,           -1.0f,  0.0f,  0.0f,    1.0f, 0.0f,

      -0.25f,  0.0f, 0.25f,         -1.0f,  0.0f,  0.0f,    0.0f, 0.0f,
    };

    GLfloat verts[100000];
    if (isModule == 1.0) {
        for (int i = 0; i < sizeof(verts2) / sizeof(verts2[0]); i++) {
            verts[i] = verts2[i];
        }
    }
    else {
        //generateCylinderPoints(verts, 50, .15, 0.3f);
        global_num_light_comp = generateCylinderPoints(verts, 25, .8, 0.1f, 0.4f, false, 0.0f, 0.0f);
    }


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, &mesh.vbo);
}


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
